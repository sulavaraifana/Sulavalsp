<?php

namespace Database\Seeders;

use App\Models\Admin;
use App\Models\Aspirasi;
use App\Models\Input_aspirasi;
use App\Models\Kategori;
use App\Models\Penduduk;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
         //Input Data Kategori
         Kategori::create(
            [
                'ket_kategori' => 'Kebersihan'
            ]
        );
        Kategori::create(
            [
                'ket_kategori' => 'Keamanan'
            ]
        );
        Kategori::create(
            [
                'ket_kategori' => 'Kesehatan'
            ]
        );
        //Input Data Penduduk
        Penduduk::create([
            'id' => '1103095804960418',
            'nama' => 'Michelle Unjani Riyanti S.Sos',
            'alamat' => 'XII Tel 13',
        ]);
        Penduduk::create([
            'id' => '1209762804061170',
            'nama' => 'Zizi Patricia Safitri',
            'alamat' => 'XII Tel 8',
        ]);
        Penduduk::create([
            'id' => '1506926508141921',
            'nama' => 'Ibrani Saptono',
            'alamat' => 'XII Tel 10',
        ]);
        Penduduk::create([
            'id' => '20208863',
            'nama' => 'Atalla Esael Anargya',
            'alamat' => 'XII Tel 13',
        ]);
        Penduduk::create([
            'id' => '20208864',
            'nama' => 'Agung Ramadhan',
            'alamat' => 'XII tel 2',
        ]);
        Penduduk::create([
            'id' => '20208865',
            'nama' => 'Arfan Dwi Prasetyo',
            'alamat' => 'XII tel 2',
        ]);
        Penduduk::create([
            'id' => '20209224',
            'nama' => 'Sulava Raifana Tabitha',
            'alamat' => 'XII tel 9',
        ]);
        Penduduk::create([
            'id' => '12345',
            'nama' => 'chelsea',
            'alamat' => 'XII tel 9',
        ]);
        //Input Data Aspirasi
          Aspirasi::create([
            'id' => 1,
            'id_aspirasi' => 1,
            'kategori_id' => 2,
            'status' => 'Menunggu',
        ]);
        Aspirasi::create([
            'id' => 2,
            'id_aspirasi' => 2,
            'kategori_id' => 3,
            'status' => 'Menunggu',
        ]);
        //Input Aspirasi
        Input_aspirasi::create([
            'nik' => '20208865',
            'kategori_id' => '2',
            'lokasi' => 'SMK TELKOM',
            'ket' => 'kehilangan helm',
        ]);
        Input_aspirasi::create([
            'nik' => '1103095804960418',
            'kategori_id' => '3',
            'lokasi' => 'XII TEL 7',
            'ket' => 'kotor',
        ]);
        //input data admin
        Admin::create([
            'username' => 'admin',
            'password' => bcrypt('password'),
        ]);
        Admin::create([
            'username' => 'admin2',
            'password' => bcrypt('12345'),
        ]);
    }
}


<?php $__env->startSection('container'); ?>
<section id="input" style="height: 100vh;">
    <div class="row d-flex  justify-content-center">
        <div class="col-sm-12 col-md-8 col-lg-6">
            <?php if(request('id') != null): ?>
            <div class="alert mt-3 alert-warning alert-dismissible fade show" role="alert">
                <strong>Terimakasih Telah Melakukan Pengaduan <br>
                    Nomor Pengaduan : <?php echo e(request('id')); ?></strong><br>
                <small class="">Silahkan Di Ingat Nomor pengaduannya!!</small>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
          
            <?php endif; ?>
            <?php if(request('nik') != null): ?>
            <div class="alert mt-3 alert-danger alert-dismissible fade show" role="alert">
               <strong> NIS Anda Belum Terdaftar!! </strong><br>
               <small>Silahkan Isi Datanya Kembali Dengan Benar</small>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
          
            <?php endif; ?>
            <div class="card">
                <div class="card-body p-5">
                    <form action="/aspirasi/store" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label fw-bold">ID Pelapor</label>
                            <input type="text" name="id" class="form-control fw-bold" readonly
                                value="<?php echo e($no); ?>" style="background-color: #9D3C72;;">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nomor Induk Siswa</label>
                            <input type="number" name="nik" value="<?php echo e(old('nik')); ?>"
                                class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="background-color: #9D3C72;">
                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Kategori</label>
                            <div class=" container row d-flex justify-content-center">
                                <div class="col-12 rounded-4 bg-gradient p-3 fw-bold" style="background-color: #9D3C72;">
                                    <div class="row ">
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-12 col-lg-4 col-md-12 ">
                                            <input class="form-check-input" value="<?php echo e($kat->id); ?>" type="radio"
                                                name="kategori_id" id="id_kategori1">
                                            <label class="form-check-label" for="id_kategori1">
                                                <?php echo e($kat->ket_kategori); ?>

                                            </label>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Lokasi</label>
                            <select class="form-control" name="lokasi" value="<?php echo e(old('lokasi')); ?>"
                                class="form-control  <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="background-color: #9D3C72;">
                            <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                            <option value="lokasi" style="background-color: #9D3C72;">pilih lokasi disini</option>
                            <option value="lokasi" style="background-color: #9D3C72;">Kantin</option>
                            <option value="lokasi">Parkiran</option>
                            <option value="lokasi" style="background-color: #9D3C72;">Kelas</option>
                                <!-- <select class="form-control" name="lokasi" value="<?php echo e(old('lokasi')); ?>"
                                class="form-control  <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="background-color: #9D3C72;"> -->
                            <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </select>
                        
                        </div>
                        <div class="mb-3" >
                            <label class="form-label fw-bold">Keterangan</label>
                            <textarea name="ket" id="" value="<?php echo e(old('ket')); ?>"
                                class="form-control <?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2" style="background-color: #9D3C72;"></textarea>
                            <?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary" style="background-color: #07133a;">Submit</button>
                    </form>
                </div>
          
            </div>
        </div>
    </div>
</section>
<br>
<br>
<br>
<br>
<br>

<section id="aspirasi" class=" py-4 justify-content-center" style="height: 100vh;">
    <div class="row justify-content-center">
        <div class="col-12 mb-3">
            <nav class="navbar navbar-expand-lg shadow border-bottom rounded-4 p-lg-3 p-sm-0 p-md-3" style="background-color: #A0C3D2;">
                <div class="container">
                    <a class="navbar-brand fw-bold text-light fs-3" href="/aspirasi">Lacak aspirasi kamu disini</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">

                    </div>
                </div>
            </nav>
        </div>
        <div class="col-6 mt-2">
            <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 pb-3 border-bottom">
                            <form action="/aspirasi" class="" method="get">
                                <label class="form-label fw-bold">Nomor Aspirasi</label>
                                <div class="input-group">
                                    <input type="text" required name="search" value="<?php echo e(request('search')); ?>"
                                        class="form-control" placeholder="Masukkan Nomor Aspirasi"
                                        aria-label="Recipient's username" aria-describedby="button-addon2" style="background-color: #EAC7C7;">
                                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2"><i
                                            class="bi bi-search"></i></button>
                                </div>
                            </form>
                        </div>
                        <?php if(request('search') != null): ?>
                        <div class="col-12 px-4  py-3">
                            <?php $__currentLoopData = $aspirasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex">
                                <p class="fw-bold p-0 m-0 me-2">Nomor Pengaduan : </p>
                                <p class="p-0 m-0"><?php echo e($as->id); ?></p>
                            </div>
                            <div class="d-flex">
                                <p class="fw-bold p-0 m-0 me-2">Status : </p>
                                <p class="p-0 m-0"><?php echo e($as->status); ?></p>
                            </div>
                            <div class="d-flex">
                                <p class="fw-bold p-0 m-0 me-2">Kategori : </p>
                                <p class="p-0 m-0"><?php echo e($as->kategori->ket_kategori); ?></p>
                            </div>
                            <div class="d-flex">
                                <p class="fw-bold p-0 m-0 me-2">Alamat : </p>
                                <p class="p-0 m-0"><?php echo e($as->input_aspirasi->lokasi); ?></p>
                            </div>
                            <div class="d-block">
                                <p class="fw-bold p-0 m-0 me-2">Keterangan : </p>
                                <p class="p-0 m-0"><?php echo e($as->input_aspirasi->ket); ?></p>
                            </div>

                            <?php if($as['status'] == 'Selesai' and $as['feedback'] == null): ?>
                            <form action="/aspirasi/feedback" method="POST" class=" p-2  rounded-2 text-center">
                                <?php echo csrf_field(); ?>
                                <div class="btn btn-dark">
                                    <input type="hidden" name="id_aspirasi" value="<?php echo e($as->id); ?>">
                                    <input type="radio" class="" required name="feedback" value="1" id="">
                                    <label class="form-check-label">
                                        1
                                    </label>
                                </div>
                                <div class="btn-danger btn">
                                    <input type="radio" name="feedback" required value="2" id="">
                                    <label class="form-check-label">
                                        2
                                    </label>
                                </div>
                                <div class="btn btn-warning">
                                    <input type="radio" name="feedback" required value="3" id="">
                                    <label class="form-check-label">
                                        3
                                    </label>
                                </div>
                                <div class="btn btn-success">
                                    <input type="radio" name="feedback" required value="4" id="">
                                    <label class="form-check-label">
                                        4
                                    </label>
                                </div>
                                <div class="btn btn-primary"> <input type="radio" required name="feedback" value="5"
                                        id="">
                                    <label class="form-check-label">
                                        5
                                    </label></div>
                                <button type="submit" class="btn btn-secondary text-light"><i
                                        class="bi bi-send-fill"></i> </button>
                            </form>
                            <?php endif; ?>
                    
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <?php endif; ?>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pengaduanlsp\pengaduanlsp\resources\views/aspirasi.blade.php ENDPATH**/ ?>
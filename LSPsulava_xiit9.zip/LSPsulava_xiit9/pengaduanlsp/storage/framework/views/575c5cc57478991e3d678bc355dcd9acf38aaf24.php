
<?php $__env->startSection('container'); ?>
<section id="" class="justify-content-center py-4" style="height: 100vh">
    <div class="row">

        <div class="col-12">
            <div class="card">
                <div class="card-body p-4 ">
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active " aria-current="page" data-bs-toggle="tab" href="#aspirasi">Aspirasi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#history" data-bs-toggle="tab">History</a>
                        </li>

                    </ul>
                   <div class="row my-2 mt-4 justify-content-center">
                    <div class="col-8">
                        <div class="row justify-content-center">
                            <div class="col-3">
                                <div class="dropdown">
                                    <button class="btn btn-outline-secondary w-100 dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                      Kategori
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item" href="/admin?kategori=<?php echo e($kat->id); ?>"><?php echo e($kat->ket_kategori); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                  </div>
                            </div>
                            <div class="col-3">
                                <div class="dropdown">
                                    <button class="btn btn-outline-secondary w-100 dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                      Status
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                        <li><a class="dropdown-item" href="/admin?status=Menunggu">Menunggu</a></li>
                                        <li><a class="dropdown-item" href="/admin?status=Proses">Proses</a></li>
                                        <li><a class="dropdown-item" href="/admin?status=Selesai">Selesai</a></li>
                                    </ul>
                                  </div>
                            </div>
                            <div class="col-3">
                                <form action="/admin" method="get">
                                <div class="input-group mb-3">
                                   
                                        <input type="date" required class="form-control" value="<?php echo e(request('waktu')); ?>" name="waktu" aria-label="Recipient's username" aria-describedby="button-addon2">
                                        <button class="btn btn-outline-secondary" type="submit" id="button-addon2"><i class="bi bi-search"></i></button></form>
                                  </div>
                            </div>
                            <div class="col-3">
                                <form action="/admin" method="get">
                                <div class="input-group mb-3">
                                    <input type="text" required name="search"  value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Nomor aspirasi" aria-label="Recipient's username" aria-describedby="button-addon2">
                                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2"><i class="bi bi-search"></i></button>
                                  </div>
                                </form>
                            </div>
                        </div>
                    </div>
                   </div>
                    <div class="tab-content ">
                        <div role="tabpanel" id="aspirasi" class="tab-pane active">
                            <div class="row">
                               
                                <div class="col-12 ">
                                    <table class="table border-top">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Nama</th>
                                                <th scope="col">Kelas</th>
                                                <th scope="col">Kategori</th>
                                                <th scope="col">Lokasi</th>
                                                <th scope="col">Keterangan</th>
                                                <th scope="col">Waktu</th>
                                                <th scope="col">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $aspirasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($as->id); ?></th>
                                                <td><?php echo e($as->input_aspirasi->penduduk->nama); ?></td>
                                                <td><?php echo e($as->input_aspirasi->penduduk->alamat); ?></td>
                                                <td><?php echo e($as->kategori->ket_kategori); ?></td>
                                                <td><?php echo e($as->input_aspirasi->lokasi); ?></td>
                                                <td><?php echo e($as->input_aspirasi->ket); ?></td>
                                                <td><?php echo e($as->created_at); ?></td>
                                                <td>  <?php if($as['status'] == 'Menunggu'): ?>
                                                    <form action="/admin/status" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="status" value="Proses">
                                                        <input type="hidden" name="id_aspirasi"
                                                            value="<?php echo e($as->id_aspirasi); ?>">
                                                        <button type="submit"
                                                            class="btn btn-primary btn-sm mb-3 w-100">Proses</button>
                                                    </form>
                                                <?php elseif($as['status'] == 'Proses'): ?>
                                                <form action="/admin/status" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="status" value="Selesai">
                                                    <input type="hidden" name="id_aspirasi"
                                                        value="<?php echo e($as->id_aspirasi); ?>">
                                                    <button type="submit"
                                                        class="btn btn-success btn-sm mb-3 w-100">Selesai</button>
                                                </form>
                                                <?php else: ?>
                                                <button type="submit"
                                                class="btn btn-secondary btn-sm mb-3 w-100" disabled>Selesai</button>
                                                <?php endif; ?>
                                                </td>
                                                <td>
                                                    <form action="/admin/delete" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id_aspirasi" value="<?php echo e($as->id_aspirasi); ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm mb-3 w-100">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                    <?php if($aspirasi->count()): ?>

                                    <?php else: ?>
                                    <p class="text-center fs-4 mt-5">Tidak ada Aspirasi Masyarakat. </p>
                                    <?php endif; ?>
                                   <div class="d-flex justify-content-end">
                                    <?php echo e($aspirasi->links()); ?>

                                   </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" id="history" class="tab-pane ">
                            <div class="row ">
                                <div class="col-12 ">
                                    <table class="table border-top">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Nama</th>
                                                <th scope="col">Kelas</th>
                                                <th scope="col">Kategori</th>
                                                <th scope="col">Lokasi</th>
                                                <th scope="col">Keterangan</th>
                                                <th scope="col">Waktu</th>
                                                <th scope="col">Ratting</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($as->id); ?></th>
                                                <td><?php echo e($as->input_aspirasi->penduduk->nama); ?></td>
                                                <td><?php echo e($as->input_aspirasi->penduduk->alamat); ?></td>
                                                <td><?php echo e($as->kategori->ket_kategori); ?></td>
                                                <td><?php echo e($as->input_aspirasi->lokasi); ?></td>
                                                <td><?php echo e($as->input_aspirasi->ket); ?></td>
                                                <td><?php echo e($as->created_at); ?></td>
                                                <td> <div class=" text-center fw-bold">
                                                    <?php echo e($as->feedback); ?>

                                                </div>
                                                </td>
                                                <td>
                                                    <form action="/admin/delete" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id_aspirasi" value="<?php echo e($as->id_aspirasi); ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm mb-3 w-100">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                    <?php if($selesai->count()): ?>
                                    <?php else: ?>
                                    <p class="text-center fs-4 mt-5">Tidak ada Aspirasi Masyarakat. </p>
                                    <?php endif; ?>
                                    <div class="d-flex justify-content-end">
                                        <?php echo e($selesai->links()); ?>

                                       </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>

      
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pengaduanlsp\pengaduanlsp\resources\views/Admin.blade.php ENDPATH**/ ?>